/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "pid.h"
#include "motor.h"
//#include <math.h>

float motor_pwm, setpoint, pid_fb;

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    LED_Write(0); //on board led off
           
    QuadDec_Start(); //quadrature decoder module (to sense cable distance)
    QuadDec_WriteCounter(0); //reset measure cable distance (it resets to 32768)
        
    Motor_Start();            
    
    PID_Init();
    PID_Set_Gains(6000.0, 15.0, 0.0);
    PID_Set_Setpoint(&setpoint);
    PID_Set_Input(&pid_fb);
    PID_Set_Output(&motor_pwm);
    
    PID_ISR_StartEx(PID_Tick); //pid ticker routine is defined in pid.c
    PID_Tick_Timer_Start(); //100Hz PID timer 
      
    setpoint = 0;

    for(;;)
    {
        /* Place your application code here. */
        pid_fb = (int)QuadDec_ReadCounter() - 32768;        
        Motor_Bidirectional((int)motor_pwm);        
        //Motor_Bidirectional(pid_fb*2731);        
        
    }
}

/* [] END OF FILE */

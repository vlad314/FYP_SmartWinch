/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef MILLIS_H
#define MILLIS_H

#include "project.h"
    
#define millis() long_millis
 
CY_ISR_PROTO(Millis_Tick);    
void Millis_Start();
    
//elapsed milliseconds - will overflow after ~50 days
volatile extern unsigned long long long_millis;
 
#endif

/* [] END OF FILE */
